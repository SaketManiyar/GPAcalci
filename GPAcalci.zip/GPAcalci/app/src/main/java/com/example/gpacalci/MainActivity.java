package com.example.gpacalci;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    int c1,c2,c3,c4,c5,c6,c7,c8;
    int g1,g2,g3,g4,g5,g6,g7,g8;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText et1 = findViewById(R.id.editText10);
        final EditText et2 = findViewById(R.id.editText6);
        final EditText et3 = findViewById(R.id.editText);
        final EditText et4 = findViewById(R.id.editText2);
        final EditText et5 = findViewById(R.id.editText3);
        final EditText et6 = findViewById(R.id.editText4);
        final EditText et7 = findViewById(R.id.editText5);
        final EditText et8 = findViewById(R.id.editText7);

        final TextView display = findViewById(R.id.textView3);

        Button result = findViewById(R.id.button);
        Button reset = findViewById(R.id.button2);

        final EditText s1 = findViewById(R.id.s1);
        final EditText s2 = findViewById(R.id.s2);
        final EditText s3 = findViewById(R.id.s3);
        final EditText s4 = findViewById(R.id.s4);
        final EditText s5 = findViewById(R.id.s5);
        final EditText s6 = findViewById(R.id.s6);
        final EditText s7 = findViewById(R.id.s7);
        final EditText s8 = findViewById(R.id.s8);

        result.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(et1.getText().toString().equals("")){
                    c1=0;
                }else{
                    c1=Integer.parseInt(et1.getText().toString());}
                if(et2.getText().toString().equals("")){
                    c2=0;
                }else{
                    c2=Integer.parseInt(et2.getText().toString());}
                if(et3.getText().toString().equals("")){
                    c3=0;
                }else{
                    c3=Integer.parseInt(et3.getText().toString());}
                if(et4.getText().toString().equals("")){
                    c4=0;
                }else{
                    c4=Integer.parseInt(et4.getText().toString());}
                if(et5.getText().toString().equals("")){
                    c5=0;
                }else{
                    c5=Integer.parseInt(et5.getText().toString());}
                if(et6.getText().toString().equals("")){
                    c6=0;
                }else{
                    c6=Integer.parseInt(et6.getText().toString());}
                if(et7.getText().toString().equals("")){
                    c7=0;
                }else{
                    c7=Integer.parseInt(et7.getText().toString());}
                if(et8.getText().toString().equals("")){
                    c8=0;
                }else{
                    c8=Integer.parseInt(et8.getText().toString());}

                if(s1.getText().toString().equals("")){
                    g1=0;
                }else{
                    g1=Integer.parseInt(s1.getText().toString());}
                if(s2.getText().toString().equals("")){
                    g2=0;
                }else{
                    g2=Integer.parseInt(s2.getText().toString());}
                if(s3.getText().toString().equals("")){
                    g3=0;
                }else{
                    g3=Integer.parseInt(s3.getText().toString());}
                if(s4.getText().toString().equals("")){
                    g4=0;
                }else{
                    g4=Integer.parseInt(s4.getText().toString());}
                if(s5.getText().toString().equals("")){
                    g5=0;
                }else{
                    g5=Integer.parseInt(s5.getText().toString());}
                if(s6.getText().toString().equals("")){
                    g6=0;
                }else{
                    g6=Integer.parseInt(s6.getText().toString());}
                if(s7.getText().toString().equals("")){
                    g7=0;
                }else{
                    g7=Integer.parseInt(s7.getText().toString());}
                if(s8.getText().toString().equals("")){
                    g8=0;
                }else{
                    g8=Integer.parseInt(s8.getText().toString());}

                int a1=c1*g1;
                int a2=c2*g2;
                int a3=c3*g3;
                int a4=c4*g4;
                int a5=c5*g5;
                int a6=c6*g6;
                int a7=c7*g7;
                int a8=c8*g8;

                Float a=(float)(a1+a2+a3+a4+a5+a6+a7+a8);
                Float c=(float)(c1+c2+c3+c4+c5+c6+c7+c8);
                Float dis=a/c;
                String result=String.valueOf(dis);

                display.setText(result);

            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText("");
                et2.setText("");
                et3.setText("");
                et4.setText("");
                et5.setText("");
                et6.setText("");
                et7.setText("");
                et8.setText("");
                s1.setText("");
                s2.setText("");
                s3.setText("");
                s4.setText("");
                s5.setText("");
                s6.setText("");
                s7.setText("");
                s8.setText("");

            }
        });


    }
}
